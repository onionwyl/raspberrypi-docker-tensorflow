raise ImportError(
    'PIL.OleFileIO is deprecated. Use the olefile Python package '
    'instead. This module will be removed in a future version.'
)
